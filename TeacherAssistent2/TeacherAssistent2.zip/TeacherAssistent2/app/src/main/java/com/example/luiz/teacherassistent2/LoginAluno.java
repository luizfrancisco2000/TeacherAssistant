package com.example.luiz.teacherassistent2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class LoginAluno extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_login_aluno);
        Button buttonConfirmar = (Button) findViewById(R.id.confirmarButton);
        Button buttonCancelar = (Button) findViewById(R.id.cancelarButton);
        
    }
}
