package com.example.luiz.teacherassistent2;

import android.os.AsyncTask;
import android.os.ResultReceiver;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import org.apache.*;
import javax.xml.transform.Result;

/**
 * Created by Chico on 13/03/2018.
 */

public class HttpService{
    public static void cadastro(){
        HttpClient
    }
}
