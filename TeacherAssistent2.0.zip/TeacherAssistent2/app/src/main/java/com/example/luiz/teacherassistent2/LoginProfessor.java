package com.example.luiz.teacherassistent2;

/**
 * Created by Chico on 28/02/2018.
 */

public class LoginProfessor {
}
