package com.example.luiz.teacherassistent2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.net.URL;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

/**
 * Created by Luiz on 07/03/2018.
 */

public class AlunoDAO extends HttpService{
    Aluno aluno;
    URL url;
    protected void CadastrarAluno(){
        HttpService();
    }
}
